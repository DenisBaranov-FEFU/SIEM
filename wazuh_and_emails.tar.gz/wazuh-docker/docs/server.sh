#! /bin/sh

mdbook serve